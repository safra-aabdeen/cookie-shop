<?php
// Determine environment (Local XAMPP vs Live Host / InfinityFree)
$is_local = (
    in_array($_SERVER['SERVER_NAME'] ?? '', ['localhost', '127.0.0.1', '::1']) ||
    in_array($_SERVER['HTTP_HOST'] ?? '', ['localhost', '127.0.0.1']) ||
    (php_sapi_name() === 'cli' && empty($_SERVER['HTTP_HOST']))
);

if ($is_local) {
    // Local XAMPP Settings
    $servername = "localhost";
    $username   = "root";
    $password   = "";
    $dbname     = "cookie_shop";
} else {
    // ==========================================
    // InfinityFree MySQL Database Configuration
    // (InfinityFree Dashboard -> Account if0_43165133 -> MySQL Details)
    $servername = "sql305.byetcluster.com";     // Your MySQL Hostname from InfinityFree
    $username   = "if0_43165133";                // Your MySQL Username
    $password   = "jnCyVdSJMYsNXt";             // Your InfinityFree Account Password
    $dbname     = "if0_43165133_cookie_shop";    // Your Database Name
}

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("<div style='font-family:sans-serif;padding:25px;margin:30px auto;max-width:600px;background:#ffebee;color:#c62828;border-radius:12px;border:1px solid #ef9a9a;'>
         <h2 style='margin-top:0;'>⚠️ Database Connection Failed</h2>
         <p><strong>Error:</strong> " . htmlspecialchars($conn->connect_error) . "</p>
         <hr style='border:none;border-top:1px solid #ffcdd2;margin:15px 0;'>
         <p>Please make sure you have created the MySQL database in your InfinityFree control panel and updated <code>config.php</code> with your:</p>
         <ul>
           <li><strong>MySQL Hostname</strong> (e.g., <code>sqlXXX.infinityfree.com</code>)</li>
           <li><strong>MySQL Username</strong> (e.g., <code>if0_XXXXXXXX</code>)</li>
           <li><strong>MySQL Password</strong> (InfinityFree Account / vPanel Password)</li>
           <li><strong>Database Name</strong> (e.g., <code>if0_XXXXXXXX_cookie_shop</code>)</li>
         </ul>
         </div>");
}

// Set charset
$conn->set_charset("utf8mb4");

// Load ID generation & formatting helper
require_once __DIR__ . '/id_helper.php';
?>
